how to run 
first install wamp64
then place the folder in www
then import doc database 
passwords are 123 
admin
admin@doc.com  

doctors
merilin@doc.com
chimuti@doc.com
samuri@doc.com

patientslam@gmail.com
ben@gmail.com
chris@gmail.com



