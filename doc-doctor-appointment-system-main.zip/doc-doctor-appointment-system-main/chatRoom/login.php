<?php
include "db.php";
session_start();

if(isset($_POST["name"]) && isset($_POST["phone"])){
  
  $name = $_POST["name"];
  $phone = $_POST["phone"];

  // Validate name (required)
  if(empty($name)) {
    echo "<script>alert('Name is required.');</script>";
  } else {
    // Validate phone number (required and 10 digits)
    $phone = preg_replace('/[^0-9]/', '', $phone); // Remove non-digit characters
    if(strlen($phone) !== 10) {
      echo "<script>alert('Phone number must be 10 digits.');</script>";
    } else {
      // Check if the user exists or insert a new user
      $q = "SELECT * FROM `user` WHERE uname='$name' && phone='$phone'";
      if($rq = mysqli_query($db, $q)) {
        if(mysqli_num_rows($rq) === 1) {
          $_SESSION["userName"] = $name;
          $_SESSION["phone"] = $phone;
          header("location: index.php");
        } else {
          $q = "INSERT INTO `user`(`uname`, `phone`) VALUES ('$name', '$phone')";
          if($rq = mysqli_query($db, $q)) {
            $q = "SELECT * FROM `user` WHERE uname='$name' && phone='$phone'";
            if($rq = mysqli_query($db, $q)) {
              if(mysqli_num_rows($rq) === 1) {
                $_SESSION["userName"] = $name;
                $_SESSION["phone"] = $phone;
                header("location: index.php");
              }
            }
          }
        }
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doc_ChatRoom</title>
</head>
<link rel="stylesheet" href="../ChatApp/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
<body>
  <style>body{
    background-image: url(../img/steto.jpg);
    margin: 2%;
    background-color: #F6F7FA;
}
</style>
  <div class="wrapper">
    <section class="form login">
      <header><U><I><B>DOC_CHATROOM (FEEDBACK)</B></I></U></header><br>
      
   <form action="" method="post">
    
   <div class="error-text"></div>
        <div class="field input">
      <h3>Alias</h3>
      <input type="text" placeholder="The name you want to use" name="name" >
      <h3>Mobile No:</h3>
      <input type="number" placeholder="with country code" min="1111111" max="999999999999999" name="phone" >
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Continue to Chat">
        </div>
    </form>
</body>
</html>
