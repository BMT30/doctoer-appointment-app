
<?php
session_start();
include "db.php";
$msg = $_GET["msg"];
$phone = $_SESSION["phone"];
$name = $_SESSION["userName"];

$q = "SELECT * FROM `user` WHERE phone='$phone'";
if ($rq = mysqli_query($db, $q)) {
  if (mysqli_num_rows($rq) == 1) {

    $q = "INSERT INTO `msg`(`phone`, `msg`, `uname`) VALUES ('$phone','$msg','$name')";
    $rq = mysqli_query($db, $q);


  }
}



?>