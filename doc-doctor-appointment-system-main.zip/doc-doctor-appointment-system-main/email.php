<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:/wamp64/www/doc-doctor-appointment-system-main/PHPMailer-master/src/PHPMailer.php';
require 'C:/wamp64/www/doc-doctor-appointment-system-main/PHPMailer-master/src/PHPMailer.php';
require 'C:/wamp64/www/doc-doctor-appointment-system-main/PHPMailer-master/src/PHPMailer.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $message = $_POST["message"];

  // Set up PHPMailer
  $mail = new PHPMailer();
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->Port = 587;
  $mail->SMTPSecure = 'tls';
  $mail->SMTPAuth = true;
  $mail->Username = 'cchifuzhe@gmail.com';
  $mail->Password = 'a1s2d3f4g5asdfg12345';

  // Set up the email
  $mail->setFrom($email, $name);
  $mail->addAddress('cchifuzhe@gmail.com');
  $mail->Subject = 'New Contact Form Submission';
  $mail->Body = "Name: $name\nEmail: $email\nMessage: $message";

  // Send the email
  if ($mail->send()) {
    echo "Thank you for your message. We'll get back to you soon!";
  } else {
    echo "Oops! Something went wrong. Please try again later.";
  }
}
?>