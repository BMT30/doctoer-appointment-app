

<?php
session_start();

if (isset($_SESSION["user"])) {
    if ($_SESSION["user"] == "" || $_SESSION['usertype'] != 'a') {
        header("location: ../appointment.php");
        exit; // Exit after redirection
    }
} else {
    header("location: ../login.php");
    exit; // Exit after redirection
}

if (isset($_GET["id"])) {
    // Import database connection
    include("../connection.php");

    $id = $_GET["id"];

    // Delete appointment by ID
    $sql = "DELETE FROM appointment WHERE appoid = ?";
    $stmt = $database->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Redirect to appointment.php
    header("location: appointment.php");
    exit; // Exit after redirection
}
?>
 