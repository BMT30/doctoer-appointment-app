<?php
session_start();
if (isset($_SESSION["userName"]) && isset($_SESSION["phone"])) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatRoom</title>
    <style>
        body {
            background-color: #f8f9fa; /* Light gray background */
        }
        .chat {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff; /* White container background */
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #007bff; /* Blue header text */
        }
        h2 {
            color: #333; /* Dark gray subheader text */
        }
        span {
            font-weight: bold;
        }
        input[type="text"] {
            border: 1px solid #ced4da; /* Light gray border */
            border-radius: 5px;
            padding: 8px;
            width: 100%;
        }
        button {
            background-color: #007bff; /* Blue submit button */
            color: #ffffff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <h1>ChatRoom</h1>
    <div class="chat">
        <h2>You are Welcome, <span><?= $_SESSION["userName"] ?></span></h2>
        <div class="msg"></div>
        <div class="input_msg">
            <input type="text" placeholder="Write a message here" id="input_msg">
            <button onclick="update()">Send</button>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
<?php
} else {
    header("location: loginchat.php");
}
?>
